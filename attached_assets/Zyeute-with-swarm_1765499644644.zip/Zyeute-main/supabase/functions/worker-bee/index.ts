/**
 * 🐝 Colony OS Worker Bee - Supabase Edge Function
 * 
 * The heart of the swarm! This function:
 * 1. Polls colony_tasks for pending work
 * 2. Routes tasks to specialized bee handlers
 * 3. Updates task status in real-time
 * 4. Implements circuit breaker for resilience
 * 
 * Invoked via: POST /functions/v1/worker-bee
 * Or scheduled via pg_cron for continuous processing
 */

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

// ═══════════════════════════════════════════════════════════════
// CONFIGURATION
// ═══════════════════════════════════════════════════════════════

const WORKER_ID = `worker-bee-${crypto.randomUUID().slice(0, 8)}`;
const MAX_RETRIES = 3;
const CIRCUIT_BREAKER_THRESHOLD = 5; // Errors before circuit opens
const CIRCUIT_BREAKER_RESET_MS = 30000; // 30 seconds

// Circuit breaker state
let consecutiveErrors = 0;
let circuitOpen = false;
let circuitOpenedAt: number | null = null;

// ═══════════════════════════════════════════════════════════════
// BEE HANDLERS - Specialized processing for each bee type
// ═══════════════════════════════════════════════════════════════

type BeeType = 'finance' | 'security' | 'joual' | 'poutine' | 'hockey' | 'region';

interface TaskMetadata {
  target_bee?: BeeType;
  swarm_mode?: boolean;
  user_id?: string;
  context?: Record<string, unknown>;
}

interface BeeResult {
  success: boolean;
  response: string;
  confidence: number;
  metadata?: Record<string, unknown>;
}

/**
 * 🗣️ JoualBee - Quebec French language processing
 * Handles Joual dialect, translations, and cultural expressions
 */
async function handleJoualBee(command: string, metadata: TaskMetadata): Promise<BeeResult> {
  console.log(`🗣️ JoualBee processing: ${command.substring(0, 50)}...`);
  
  // Pattern matching for common Joual requests
  const joualPatterns: Record<string, string> = {
    // Greetings
    'bonjour|salut|allo': "Heille! Ça roule? 🐝",
    'comment ça va|ça va': "Tiguidou! Pis toé, ça file?",
    
    // Expressions
    'traduction|traduis|translate': "Ouin, j'peux t'aider avec ça!",
    'expression|joual': "Check ben ça, j'te montre comment on parle icitte!",
    
    // Content generation
    'caption|légende': "J'te prépare une caption qui a du punch!",
    'hashtag': "Voici des hashtags québécois pour toi!",
  };

  // Check patterns
  const lowerCommand = command.toLowerCase();
  for (const [pattern, response] of Object.entries(joualPatterns)) {
    if (new RegExp(pattern).test(lowerCommand)) {
      return {
        success: true,
        response: response,
        confidence: 0.85,
        metadata: { bee: 'joual', pattern_matched: pattern }
      };
    }
  }

  // Default Joual response
  return {
    success: true,
    response: `Tiguidou! J'ai ben compris ta demande. "${command.substring(0, 100)}..." - J'travaille là-dessus! 🐝⚜️`,
    confidence: 0.75,
    metadata: { bee: 'joual', fallback: true }
  };
}

/**
 * 🏒 HockeyBee - Hockey content and Habs updates
 */
async function handleHockeyBee(command: string, metadata: TaskMetadata): Promise<BeeResult> {
  console.log(`🏒 HockeyBee processing: ${command.substring(0, 50)}...`);
  
  const hockeyKeywords = ['habs', 'canadiens', 'nhl', 'hockey', 'goal', 'playoff', 'leafs', 'bruins'];
  const hasHockeyContext = hockeyKeywords.some(k => command.toLowerCase().includes(k));
  
  if (hasHockeyContext) {
    return {
      success: true,
      response: "🏒 GO HABS GO! J'analyse les stats pis les highlights pour toé! ⚜️",
      confidence: 0.9,
      metadata: { bee: 'hockey', context: 'nhl' }
    };
  }

  return {
    success: true,
    response: "🏒 HockeyBee est prêt! Parle-moé des Canadiens ou de la LNH!",
    confidence: 0.7,
    metadata: { bee: 'hockey' }
  };
}

/**
 * 🍟 PoutineBee - Food, restaurants, and Quebec cuisine
 */
async function handlePoutineBee(command: string, metadata: TaskMetadata): Promise<BeeResult> {
  console.log(`🍟 PoutineBee processing: ${command.substring(0, 50)}...`);
  
  return {
    success: true,
    response: "🍟 Miam! PoutineBee à ton service! Une belle pout bien graisseuse, ça?",
    confidence: 0.85,
    metadata: { bee: 'poutine' }
  };
}

/**
 * 💰 FinanceBee - Revenue, Stripe, billing
 */
async function handleFinanceBee(command: string, metadata: TaskMetadata): Promise<BeeResult> {
  console.log(`💰 FinanceBee processing: ${command.substring(0, 50)}...`);
  
  return {
    success: true,
    response: "💰 FinanceBee analyse tes données financières... Donne-moé une seconde!",
    confidence: 0.8,
    metadata: { bee: 'finance' }
  };
}

/**
 * 🔒 SecurityBee - Moderation, bans, safety
 */
async function handleSecurityBee(command: string, metadata: TaskMetadata): Promise<BeeResult> {
  console.log(`🔒 SecurityBee processing: ${command.substring(0, 50)}...`);
  
  return {
    success: true,
    response: "🔒 SecurityBee surveille! Contenu analysé pour la sécurité de la communauté.",
    confidence: 0.95,
    metadata: { bee: 'security' }
  };
}

/**
 * 📍 RegionBee - Location-based content and local features
 */
async function handleRegionBee(command: string, metadata: TaskMetadata): Promise<BeeResult> {
  console.log(`📍 RegionBee processing: ${command.substring(0, 50)}...`);
  
  const regions = ['montreal', 'mtl', 'quebec', 'gaspésie', 'plateau', 'mile end', '514', '418'];
  const matchedRegion = regions.find(r => command.toLowerCase().includes(r));
  
  return {
    success: true,
    response: matchedRegion 
      ? `📍 Ah, ${matchedRegion.toUpperCase()}! Belle région ça! J'connais ben ce coin-là!`
      : "📍 RegionBee cherche le meilleur spot pour toé au Québec!",
    confidence: matchedRegion ? 0.9 : 0.7,
    metadata: { bee: 'region', detected_region: matchedRegion }
  };
}

// ═══════════════════════════════════════════════════════════════
// TASK ROUTER - Dispatches tasks to appropriate bee
// ═══════════════════════════════════════════════════════════════

async function routeTaskToBee(
  command: string, 
  beeType: BeeType | null,
  metadata: TaskMetadata
): Promise<BeeResult> {
  
  // If specific bee requested, route directly
  if (beeType) {
    switch (beeType) {
      case 'joual': return handleJoualBee(command, metadata);
      case 'hockey': return handleHockeyBee(command, metadata);
      case 'poutine': return handlePoutineBee(command, metadata);
      case 'finance': return handleFinanceBee(command, metadata);
      case 'security': return handleSecurityBee(command, metadata);
      case 'region': return handleRegionBee(command, metadata);
    }
  }

  // Auto-detect bee type from command content
  const cmd = command.toLowerCase();
  
  if (cmd.includes('hockey') || cmd.includes('habs') || cmd.includes('canadiens')) {
    return handleHockeyBee(command, metadata);
  }
  if (cmd.includes('poutine') || cmd.includes('recette') || cmd.includes('restaurant')) {
    return handlePoutineBee(command, metadata);
  }
  if (cmd.includes('revenue') || cmd.includes('stripe') || cmd.includes('facture')) {
    return handleFinanceBee(command, metadata);
  }
  if (cmd.includes('security') || cmd.includes('ban') || cmd.includes('modération')) {
    return handleSecurityBee(command, metadata);
  }
  if (cmd.includes('montreal') || cmd.includes('région') || cmd.includes('514')) {
    return handleRegionBee(command, metadata);
  }

  // Default to JoualBee for general Quebec French handling
  return handleJoualBee(command, metadata);
}

// ═══════════════════════════════════════════════════════════════
// CIRCUIT BREAKER - Fault tolerance
// ═══════════════════════════════════════════════════════════════

function checkCircuitBreaker(): boolean {
  if (!circuitOpen) return true;
  
  // Check if circuit should reset
  if (circuitOpenedAt && Date.now() - circuitOpenedAt > CIRCUIT_BREAKER_RESET_MS) {
    console.log('🔄 Circuit breaker resetting (half-open state)');
    circuitOpen = false;
    consecutiveErrors = 0;
    return true;
  }
  
  console.log('⚡ Circuit breaker OPEN - rejecting request');
  return false;
}

function recordSuccess() {
  consecutiveErrors = 0;
  if (circuitOpen) {
    console.log('✅ Circuit breaker closed - service recovered');
    circuitOpen = false;
  }
}

function recordError() {
  consecutiveErrors++;
  console.log(`⚠️ Error recorded (${consecutiveErrors}/${CIRCUIT_BREAKER_THRESHOLD})`);
  
  if (consecutiveErrors >= CIRCUIT_BREAKER_THRESHOLD && !circuitOpen) {
    console.log('🔴 Circuit breaker OPENED - too many errors');
    circuitOpen = true;
    circuitOpenedAt = Date.now();
  }
}

// ═══════════════════════════════════════════════════════════════
// MAIN HANDLER
// ═══════════════════════════════════════════════════════════════

serve(async (req) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  };

  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  // Check circuit breaker
  if (!checkCircuitBreaker()) {
    return new Response(JSON.stringify({
      error: 'Service temporarily unavailable',
      circuit_breaker: 'open',
      retry_after_ms: CIRCUIT_BREAKER_RESET_MS
    }), {
      status: 503,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }

  try {
    // Initialize Supabase admin client
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') || '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
    );

    console.log(`🐝 Worker Bee ${WORKER_ID} polling for tasks...`);

    // Get next pending task using the database function
    const { data: tasks, error: fetchError } = await supabaseAdmin
      .rpc('get_next_colony_task', { worker_id: WORKER_ID });

    if (fetchError) {
      console.error('Error fetching task:', fetchError);
      recordError();
      throw fetchError;
    }

    // No tasks available
    if (!tasks || tasks.length === 0) {
      return new Response(JSON.stringify({
        status: 'idle',
        message: 'No pending tasks',
        worker_id: WORKER_ID
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const task = tasks[0];
    console.log(`📋 Processing task ${task.id}: ${task.command.substring(0, 50)}...`);

    // Parse metadata
    let metadata: TaskMetadata = {};
    try {
      // Fetch full task to get metadata
      const { data: fullTask } = await supabaseAdmin
        .from('colony_tasks')
        .select('metadata')
        .eq('id', task.id)
        .single();
      
      metadata = (fullTask?.metadata as TaskMetadata) || {};
    } catch (e) {
      console.warn('Could not parse task metadata:', e);
    }

    // Route to appropriate bee
    const beeType = metadata.target_bee || null;
    const result = await routeTaskToBee(task.command, beeType, metadata);

    // Update task with result
    const { error: updateError } = await supabaseAdmin
      .from('colony_tasks')
      .update({
        status: result.success ? 'done' : 'error',
        result: result.response,
        executed_at: new Date().toISOString(),
        executed_by: WORKER_ID,
        metadata: {
          ...metadata,
          bee_result: result.metadata,
          confidence: result.confidence
        }
      })
      .eq('id', task.id);

    if (updateError) {
      console.error('Error updating task:', updateError);
      recordError();
      throw updateError;
    }

    // Record success
    recordSuccess();

    console.log(`✅ Task ${task.id} completed by ${WORKER_ID}`);

    return new Response(JSON.stringify({
      status: 'completed',
      task_id: task.id,
      worker_id: WORKER_ID,
      bee_type: beeType || 'auto-detected',
      result: result.response,
      confidence: result.confidence
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Worker Bee error:', errorMessage);
    recordError();

    return new Response(JSON.stringify({
      error: errorMessage,
      worker_id: WORKER_ID,
      circuit_breaker_state: circuitOpen ? 'open' : 'closed',
      consecutive_errors: consecutiveErrors
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
