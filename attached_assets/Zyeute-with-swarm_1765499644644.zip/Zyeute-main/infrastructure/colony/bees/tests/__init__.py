# Tests for Colony OS Worker Bees

