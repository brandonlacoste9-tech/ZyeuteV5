/**
 * Settings Page - Premium Quebec Heritage Design
 * Instagram-style layout with beaver leather & gold aesthetic
 */

import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Header } from '@/components/Header';
import { BottomNav } from '@/components/BottomNav';
import { Avatar } from '@/components/Avatar';
import { Button } from '@/components/Button';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/Toast';
import { generateId } from '@/lib/utils';
import { QUEBEC_REGIONS } from '@/lib/quebecFeatures';
import { useBorderColor } from '@/contexts/BorderColorContext';
import { useHaptics } from '@/hooks/useHaptics';
import type { User } from '@/types';
import { logger } from '../lib/logger';

const settingsLogger = logger.withContext('Settings');


interface SettingItem {
  icon: React.ReactNode;
  label: string;
  path?: string;
  badge?: string;
  onClick?: () => void;
}

export const Settings: React.FC = () => {
  const navigate = useNavigate();
  const [user, setUser] = React.useState<User | null>(null);
  const [isLoading, setIsLoading] = React.useState(true);
  const [searchQuery, setSearchQuery] = React.useState('');
  const { borderColor, setBorderColor, defaultGold } = useBorderColor();
  const { tap, success, selection, impact } = useHaptics();

  // Fetch current user
  React.useEffect(() => {
    const fetchUser = async () => {
      setIsLoading(true);
      try {
        const { data: { user: authUser } } = await supabase.auth.getUser();

        if (!authUser) {
          navigate('/login');
          return;
        }

        const { data } = await supabase
          .from('user_profiles')
          .select('*')
          .eq('id', authUser.id)
          .single();

        if (data) {
          setUser(data);
        }
      } catch (error) {
        settingsLogger.error('Error fetching user:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchUser();
  }, [navigate]);

  // Sign out
  const handleSignOut = async () => {
    const confirmed = window.confirm('Es-tu sûr de vouloir te déconnecter?');
    if (!confirmed) return;

    toast.info('Déconnexion...');
    await supabase.auth.signOut();
    toast.success('À la prochaine! 👋');
    setTimeout(() => navigate('/login'), 500);
  };

  // Handle border color change
  const handleColorChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    selection(); // Haptic feedback for color selection
    setBorderColor(event.target.value);
    toast.success('Couleur d\'accent mise à jour! ✨');
  };

  // Reset to default gold
  const resetToGold = () => {
    tap(); // Haptic feedback for button press
    setBorderColor(defaultGold);
    success(); // Success haptic for completed action
    toast.success('Couleur réinitialisée à l\'or par défaut! ⚜️');
  };

  // Settings sections
  const yourActivitySettings: SettingItem[] = [
    {
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
        </svg>
      ),
      label: 'Tags et mentions',
      path: '/settings/tags',
    },
    {
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
        </svg>
      ),
      label: 'Commentaires',
      path: '/settings/comments',
    },
    {
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
        </svg>
      ),
      label: 'Partage et remixes',
      path: '/settings/sharing',
    },
    {
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
        </svg>
      ),
      label: 'Comptes restreints',
      path: '/settings/restricted',
    },
  ];

  const whatYouSeeSettings: SettingItem[] = [
    {
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
        </svg>
      ),
      label: 'Favoris',
      path: '/settings/favorites',
    },
    {
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2" />
        </svg>
      ),
      label: 'Comptes masqués',
      path: '/settings/muted',
    },
    {
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
        </svg>
      ),
      label: 'Préférences de contenu',
      path: '/settings/content',
    },
  ];

  const appAndMediaSettings: SettingItem[] = [
    {
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
      ),
      label: 'Photos et vidéos',
      path: '/settings/media',
    },
    {
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
        </svg>
      ),
      label: 'Audio et musique',
      path: '/settings/audio',
    },
    {
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
        </svg>
      ),
      label: 'Stockage et données',
      path: '/settings/storage',
    },
    {
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
      ),
      label: 'Paramètres de l\'app',
      path: '/settings/app',
    },
  ];

  const quebecSettings: SettingItem[] = [
    {
      icon: <span className="text-2xl">⚜️</span>,
      label: 'Région du Québec',
      path: '/settings/region',
      badge: user?.region ? QUEBEC_REGIONS.find(r => r.id === user.region)?.emoji : undefined,
    },
    {
      icon: <span className="text-2xl">🇨🇦</span>,
      label: 'Langue',
      path: '/settings/language',
      badge: 'FR',
    },
    {
      icon: <span className="text-2xl">🦫</span>,
      label: 'Ti-Guy Assistant',
      path: '/settings/voice',
    },
  ];

  const accountSettings: SettingItem[] = [
    {
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
        </svg>
      ),
      label: 'Modifier le profil',
      path: '/settings/profile',
    },
    {
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
        </svg>
      ),
      label: 'Confidentialité et sécurité',
      path: '/settings/privacy',
    },
    {
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
        </svg>
      ),
      label: 'Notifications',
      path: '/settings/notifications',
    },
    {
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
      label: 'Abonnement Premium',
      path: '/premium',
      badge: user?.subscription_tier ? '⭐' : undefined,
    },
  ];

  // Filter settings based on search
  const filterSettings = (items: SettingItem[]) => {
    if (!searchQuery) return items;
    return items.filter(item =>
      item.label.toLowerCase().includes(searchQuery.toLowerCase())
    );
  };

  // Handle setting item click
  const handleSettingClick = (item: SettingItem) => {
    tap();
    
    // Routes that exist
    const existingRoutes = [
      '/settings/tags',
      '/settings/comments',
      '/settings/sharing',
      '/settings/restricted',
      '/settings/favorites',
      '/settings/muted',
      '/settings/content',
      '/settings/media',
      '/settings/audio',
      '/settings/storage',
      '/settings/app',
      '/settings/region',
      '/settings/language',
      '/settings/voice',
      '/settings/profile',
      '/settings/privacy',
      '/settings/notifications',
      '/premium',
    ];
    
    if (item.path && existingRoutes.includes(item.path)) {
      navigate(item.path);
    } else if (item.onClick) {
      item.onClick();
    } else if (item.path) {
      // Route doesn't exist yet - show coming soon message
      toast.info(`"${item.label}" sera disponible bientôt! ⚜️`);
    }
  };

  if (isLoading || !user) {
    return (
      <div className="min-h-screen bg-black leather-overlay flex items-center justify-center">
        <div className="text-gold-400 animate-pulse-gold">Chargement...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black leather-overlay pb-20">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-black/95 backdrop-blur-sm border-b border-gold-500/20">
        <div className="max-w-2xl mx-auto px-4 py-4 flex items-center gap-4">
          <button
            onClick={() => {
              tap();
              navigate(-1);
            }}
            className="text-gold-500 hover:text-gold-400 transition-colors"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <h1 className="text-xl font-bold text-gold-500 embossed flex-1">
            Paramètres et activité
          </h1>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-4">
        {/* Search Bar */}
        <div className="mb-6">
          <div className="leather-card rounded-xl px-4 py-3 flex items-center gap-3 border-gold-500/20">
            <svg className="w-5 h-5 text-gold-500/70" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher paramètres"
              className="flex-1 bg-transparent border-none outline-none text-white placeholder-leather-400 focus:placeholder-gold-500/50"
            />
          </div>
        </div>

        {/* Your Activity Section */}
        <div className="mb-6">
          {filterSettings(yourActivitySettings).map((item, index) => (
            <button
              key={index}
              onClick={() => handleSettingClick(item)}
              className="w-full flex items-center gap-4 p-4 hover:bg-leather-800/40 transition-all rounded-xl group border-b border-leather-800/30 last:border-b-0 text-left"
            >
              <div className="text-leather-300 group-hover:text-gold-500 transition-colors">
                {item.icon}
              </div>
              <span className="flex-1 text-white font-medium group-hover:text-gold-400 transition-colors">{item.label}</span>
              <svg className="w-5 h-5 text-leather-500 group-hover:text-gold-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          ))}
        </div>

        {/* What You See Section */}
        <div className="mb-6">
          <h2 className="text-leather-400 text-xs font-bold uppercase tracking-wider mb-3 px-4">
            Ce que tu vois
          </h2>
          {filterSettings(whatYouSeeSettings).map((item, index) => (
            <button
              key={index}
              onClick={() => handleSettingClick(item)}
              className="w-full flex items-center gap-4 p-4 hover:bg-leather-800/30 transition-colors rounded-xl group text-left"
            >
              <div className="text-leather-300 group-hover:text-gold-500 transition-colors">
                {item.icon}
              </div>
              <span className="flex-1 text-white font-medium">{item.label}</span>
              <svg className="w-5 h-5 text-leather-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          ))}
        </div>

        {/* Your App and Media Section */}
        <div className="mb-6">
          <h2 className="text-leather-400 text-xs font-bold uppercase tracking-wider mb-3 px-4">
            Ton app et médias
          </h2>
          {filterSettings(appAndMediaSettings).map((item, index) => (
            <button
              key={index}
              onClick={() => handleSettingClick(item)}
              className="w-full flex items-center gap-4 p-4 hover:bg-leather-800/30 transition-colors rounded-xl group text-left"
            >
              <div className="text-leather-300 group-hover:text-gold-500 transition-colors">
                {item.icon}
              </div>
              <span className="flex-1 text-white font-medium">{item.label}</span>
              <svg className="w-5 h-5 text-leather-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          ))}
        </div>

        {/* Personalization Section */}
        <div className="mb-6">
          <h2 className="text-gold-500/70 text-xs font-bold uppercase tracking-wider mb-3 px-4">
            Personnalisation
          </h2>
          
          <div className="leather-card rounded-xl overflow-hidden stitched">
            {/* Header */}
            <div className="p-4 border-b border-leather-700/30">
              <div className="flex items-center gap-4 mb-2">
                <div className="text-gold-500">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" />
                  </svg>
                </div>
                <div className="flex-1">
                  <p className="text-white font-semibold">
                    Éclairage d&apos;accent de l&apos;app
                  </p>
                  <p className="text-sm text-leather-400 mt-0.5">
                    Couleur de bordure personnalisable autour de l&apos;app
                  </p>
                </div>
              </div>

              {/* Current Color Preview */}
              <div className="flex items-center gap-3 mt-4">
                <div 
                  className="w-16 h-16 rounded-xl border-2 border-gold-500/30 shadow-lg"
                  style={{ backgroundColor: borderColor }}
                />
                <div className="flex-1">
                  <p className="text-white text-sm font-medium mb-1">Couleur actuelle</p>
                  <p className="text-gold-500/80 font-mono text-xs">{borderColor.toUpperCase()}</p>
                </div>
              </div>
            </div>

            {/* Preset Colors */}
            <div className="p-4 border-b border-leather-700/30">
              <p className="text-white text-sm font-medium mb-3">Couleurs prédéfinies</p>
              <div className="grid grid-cols-6 gap-3">
                {[
                  { name: 'Or', color: '#FFBF00' },
                  { name: 'Rouge', color: '#FF4444' },
                  { name: 'Bleu', color: '#4444FF' },
                  { name: 'Vert', color: '#44FF44' },
                  { name: 'Violet', color: '#B744FF' },
                  { name: 'Cyan', color: '#00D4FF' },
                  { name: 'Rose', color: '#FF0080' },
                  { name: 'Orange', color: '#FF8800' },
                  { name: 'Blanc', color: '#FFFFFF' },
                  { name: 'Jaune', color: '#FFFF00' },
                  { name: 'Turquoise', color: '#00FF88' },
                  { name: 'Magenta', color: '#FF00FF' },
                ].map((preset) => (
                  <button
                    key={preset.color}
                    onClick={() => {
                      tap();
                      setBorderColor(preset.color);
                      toast.success(`Couleur changée: ${preset.name}! ✨`);
                    }}
                    className={`relative aspect-square rounded-lg border-2 transition-all hover:scale-110 ${
                      borderColor.toUpperCase() === preset.color.toUpperCase()
                        ? 'border-gold-500 ring-2 ring-gold-500/50'
                        : 'border-leather-700 hover:border-gold-500/50'
                    }`}
                    style={{ backgroundColor: preset.color }}
                    title={preset.name}
                  >
                    {borderColor.toUpperCase() === preset.color.toUpperCase() && (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <svg className="w-6 h-6 text-white drop-shadow-lg" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
                        </svg>
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Color Picker */}
            <div className="p-4 border-b border-leather-700/30">
              <p className="text-white text-sm font-medium mb-3">Couleur personnalisée</p>
              <div className="flex items-center gap-4">
                <input
                  type="color"
                  value={borderColor}
                  onChange={handleColorChange}
                  className="w-20 h-20 rounded-xl border-2 border-gold-500/50 cursor-pointer bg-transparent hover:border-gold-500 transition-colors"
                  style={{ 
                    WebkitAppearance: 'none',
                    appearance: 'none',
                    cursor: 'pointer',
                  }}
                  title="Choisir une couleur personnalisée"
                />
                <div className="flex-1">
                  <input
                    type="text"
                    value={borderColor.toUpperCase()}
                    onChange={(e) => {
                      const value = e.target.value;
                      if (/^#[0-9A-F]{6}$/i.test(value)) {
                        setBorderColor(value);
                        toast.success('Couleur mise à jour! ✨');
                      }
                    }}
                    placeholder="#FFBF00"
                    className="w-full bg-leather-800/50 border border-leather-700 rounded-lg px-4 py-2 text-white font-mono text-sm focus:outline-none focus:border-gold-500"
                  />
                  <p className="text-leather-400 text-xs mt-1">Entrer un code hexadécimal (ex: #FFBF00)</p>
                </div>
              </div>
            </div>

            {/* Reset to Default Gold Option */}
            <button
              onClick={resetToGold}
              className="w-full flex items-center justify-between p-4 hover:bg-gold-500/10 transition-colors group"
            >
              <div className="flex items-center gap-4">
                <div className="text-gold-500">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <p className="text-white font-medium group-hover:text-gold-400 transition-colors">
                    Réinitialiser à l&apos;or par défaut
                  </p>
                  <p className="text-sm text-leather-400">Retourner à la couleur d&apos;origine</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div 
                  className="w-8 h-8 rounded-lg border border-gold-500/50"
                  style={{ backgroundColor: defaultGold }}
                />
                <span className="text-sm text-gold-500/80 font-mono">{defaultGold}</span>
              </div>
            </button>
          </div>
        </div>

        {/* Quebec Heritage Section */}
        <div className="mb-6">
          <h2 className="text-gold-500 text-xs font-bold uppercase tracking-wider mb-3 px-4 flex items-center gap-2">
            <span>🇨🇦</span>
            <span>Québec</span>
          </h2>
          <div className="leather-card rounded-2xl overflow-hidden stitched">
            {filterSettings(quebecSettings).map((item, index) => (
              <button
                key={index}
                onClick={() => handleSettingClick(item)}
                className="w-full flex items-center gap-4 p-4 hover:bg-leather-700/30 transition-colors group border-b border-leather-700/30 last:border-b-0 text-left"
              >
                <div className="text-2xl group-hover:scale-110 transition-transform">
                  {item.icon}
                </div>
                <span className="flex-1 text-white font-medium">{item.label}</span>
                {item.badge && (
                  <span className="badge-premium">{item.badge}</span>
                )}
                <svg className="w-5 h-5 text-leather-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            ))}
          </div>
        </div>

        {/* Account Settings Section */}
        <div className="mb-6">
          <h2 className="text-leather-400 text-xs font-bold uppercase tracking-wider mb-3 px-4">
            Ton compte
          </h2>
          {filterSettings(accountSettings).map((item, index) => (
            <button
              key={index}
              onClick={() => handleSettingClick(item)}
              className="w-full flex items-center gap-4 p-4 hover:bg-leather-800/30 transition-colors rounded-xl group text-left"
            >
              <div className="text-leather-300 group-hover:text-gold-500 transition-colors">
                {item.icon}
              </div>
              <span className="flex-1 text-white font-medium">{item.label}</span>
              {item.badge && (
                <span className="text-gold-500 text-sm">{item.badge}</span>
              )}
              <svg className="w-5 h-5 text-leather-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          ))}
        </div>

        {/* Sign Out Button */}
        <div className="leather-card rounded-2xl p-4 mb-6 stitched">
          <button
            onClick={() => {
              impact();
              handleSignOut();
            }}
            className="w-full text-center py-3 text-red-400 font-bold hover:text-red-300 transition-colors"
          >
            Se déconnecter
          </button>
        </div>

        {/* App Info */}
        <div className="text-center text-leather-400 text-sm space-y-1">
          <p className="flex items-center justify-center gap-2">
            <span className="text-gold-500">⚜️</span>
            <span>Zyeuté v1.0.0</span>
          </p>
          <p>Fait avec fierté québécoise 🇨🇦</p>
          <p className="text-xs text-leather-500">Fait au Québec avec fierté 🦫⚜️</p>
        </div>
      </div>

      <BottomNav />
    </div>
  );
};

export default Settings;
